<?php
global $Room;
act('initroom', $msg, $connection); 